#!/bin/bash
model_type=llama3-8b
logdir="/nvme/ci_performance/log_dir/lightllm/service/${model_type}"  # 请替换为实际的日志目录
# 检查目录是否成功创建  
if [ -d "$logdir" ]; then  
    echo "目录 $logdir 正常"  
else 	
    echo "创建目录 $logdir" 
    mkdir -p "$logdir"   
fi
port=23333
request_num=1000
model_dir=/nvme/ci_performance/models/Meta-Llama-3.1-8B-Instruct/
COMMAND="LOADWORKER=4 python -m lightllm.server.api_server \
    --host 0.0.0.0                 \
    --port ${port} \
    --nccl_port 28766 \
    --tp 1                        \
    --eos_id 128009 \
    --max_req_input_len 4096  \
    --max_req_total_len 8192 \
    --max_total_token_num 480000    \
    --model_dir ${model_dir} 
    --mode triton_gqa_flashdecoding \
    --trust_remote_code \
    --data_type bf16 \
    --tokenizer_mode fast \
    --batch_max_tokens 8192 \
    --router_max_wait_tokens 10"

echo "$COMMAND"
eval "$COMMAND" > server.log 2>&1 &
timeout 600 bash -c "until curl http://0.0.0.0:${port}/health; do sleep 10; done" || { echo "Server failed to start"; pkill python; exit 1; } 

declare -a num_clients=(1 5 10 15 25 50 100)

output=2048
xiaomi_datapath="/nvme/baishihao/llm_profiler/custom_data/xiaomi_data1_medium.jsonl"

for clients in "${num_clients[@]}"; do
    
    outfile="${logdir}/lightllm##${model_type}##tp_1##inputlen_xiaomi##outputlen_${output}##clients_${clients}.json"
    if [[ -f "$outfile" ]]; then
        echo "$outfile exists:"
        cat "$outfile"
        continue
    fi
    # warmup with 40 requests
    # echo "Begin Warmup!"
    # llm_profiler --config configs/config_pileval_stream.yml \
    #     --url 0.0.0.0:"$port"/generate_stream \
    #     --num_clients "$clients" \
    #     --post_mode stream \
    #     --data_source pileval \
    #     --server_api lightllm \
    #     --data_path /nvme/ci_performance/dataset/pileval/ \
    #     --tokenizer_path "$model_dir" \
    #     --input_num 40 \
    #     --input_len 1024 \
    #     --output_len 32 > warmup.log
    echo "Begin testing, results saved in $outfile"
    llm_profiler --config configs/config_pileval_stream.yml \
        --url 0.0.0.0:"$port"/generate_stream \
        --num_clients "$clients" \
        --post_mode stream \
        --data_source custom \
        --server_api lightllm \
        --data_path "$xiaomi_datapath" \
        --tokenizer_path "$model_dir" \
        --output_len "$output" \
        --dump_file "$outfile"

done


# pkill -f python
