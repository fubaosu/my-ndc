import os
import sys
from model_infer_batchs import test_model_inference
from process_utils import kill_gpu_processes
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
from datetime import datetime

from lightllm.models.cohere.model import CohereTpPartModel
from lightllm.models.mixtral.model import MixtralTpPartModel
from lightllm.models.qwen2.model import Qwen2TpPartModel
from lightllm.models.bloom.model import BloomTpPartModel
from lightllm.models.llama.model import LlamaTpPartModel
from lightllm.models.llama_wquant.model import LlamaTpPartModelWQuant
from lightllm.models.llama_awquant.model import LlamaTpPartModelAWQuant
from lightllm.models.llama_quik.model import LlamaTpPartModelQuik
from lightllm.models.qwen2_wquant.model import QWen2TpPartModelWQuant
from lightllm.models.starcoder.model import StarcoderTpPartModel
from lightllm.models.starcoder_wquant.model import StarcoderTpPartModelWQuant
from lightllm.models.starcoder2.model import Starcoder2TpPartModel
from lightllm.models.qwen.model import QWenTpPartModel
from lightllm.models.qwen_wquant.model import QWenTpPartModelWQuant
from lightllm.models.baichuan7b.model import Baichuan7bTpPartModel
from lightllm.models.baichuan13b.model import Baichuan13bTpPartModel
from lightllm.models.baichuan2_7b.model import Baichuan2_7bTpPartModel
from lightllm.models.baichuan2_13b.model import Baichuan2_13bTpPartModel
from lightllm.models.chatglm2.model import ChatGlm2TpPartModel
from lightllm.models.internlm.model import InternlmTpPartModel
from lightllm.models.stablelm.model import StablelmTpPartModel
from lightllm.models.internlm2.model import Internlm2TpPartModel
from lightllm.models.internlm2_reward.model import Internlm2RewardTpPartModel
from lightllm.models.internlm_wquant.model import InternlmTpPartModelWQuant
from lightllm.models.internlm2_wquant.model import Internlm2TpPartModelWQuant
from lightllm.models.yi.model import YiTpPartModel
from lightllm.models.mistral.model import MistralTpPartModel
from lightllm.models.minicpm.model import MiniCPMTpPartModel
from lightllm.models.llava.model import LlavaTpPartModel
from lightllm.models.qwen_vl.model import QWenVLTpPartModel
from lightllm.models.internlm_xcomposer.model import InternlmComposerTpPartModel
from lightllm.models.gemma_2b.model import Gemma_2bTpPartModel
from lightllm.models.phi3.model import Phi3TpPartModel
from lightllm.models.deepseek2.model import Deepseek2TpPartModel
from lightllm.models.internvl.model import InternVLLlamaTpPartModel, InternVLPhi3TpPartModel
from lightllm.models.internvl.model import InternVLInternlm2TpPartModel


base_dir = "/nvme/ci_performance/models/"

in_out_lens = [(1024, 256), (2048, 256), (4096, 256), (8192, 256), (2**14, 256), (2**15, 256), ((2**16, 256))] # in_out_lens 中的数据必须以从短到长的顺序排列，否则可能有问题。
batch_sizes = [1, 2, 4, 8, 12, 16] # batch_sizes 中的数字也必须从小到大排列。

in_out_lens = [(1000, 256), (4000, 256), (8000, 256), (16000, 256), (64000, 256)] # in_out_lens 中的数据必须以从短到长的顺序排列，否则可能有问题。
model_to_class_and_path = {
    "xiaomi-100B": {
        "model_type": Internlm2TpPartModel,
        "model_path": os.path.join(base_dir, "sensechat5_102b_128k_5150"),
        "in_out_lens": in_out_lens,
        "batch_sizes": batch_sizes,
        "modes": [["triton_gqa_flashdecoding"]],
        "world_sizes": [8]
    },
}


def test_all_setting( model_name, modes, log_dir, world_sizes, in_out_lens, batch_sizes, model_class, model_path):
    log_dir = os.path.join(log_dir, str(model_name))
    os.makedirs(log_dir, exist_ok=True)
    kill_gpu_processes()
    for mode in modes:
        for world_size in world_sizes:
            for in_len, out_len in in_out_lens: 
                kill_gpu_processes()
                mode_str = "_".join(mode)
                log_file_name = f"static_{model_name}##{mode_str}##{world_size}##{in_len}##{out_len}##batch_size##.log"
                log_path = os.path.join(log_dir, log_file_name)
                print(log_path)
                test_model_inference(world_size, 
                                 model_path, 
                                 model_class, 
                                 batch_sizes, 
                                 in_len, 
                                 out_len,
                                 mode, 
                                 log_path)
    log_md_file = log_dir + ".md"
    md_file = open(log_md_file, "w")
    # write head
    heads = ['mode', 'world_size', 'batch_size', 'input_len', 'output_len', 'prefill_cost', 'first_step_latency', 'last_step_latency', 'mean_latency', 
             'prefill_throughput', 'decode_throughput', 'total_throughput',
             'card_num_per_qps']
    md_file.write(f"test model: {model_name} \r\n")
    md_file.write('|')
    for head in heads:
        md_file.write(head + "|")
    md_file.write('\r\n')
    md_file.write('|')
    for _ in range(len(heads)):
        md_file.write('------|')
    md_file.write('\r\n')
    log_files = list(os.listdir(log_dir))
    log_files = sorted(log_files, key=lambda x: tuple(map(int, x.split("##")[2:6])))
    for log_file in log_files:
        _, mode, world_size, input_len, output_len, batch_size, _ = log_file.split("##")
        fp_file = open(os.path.join(log_dir, log_file), "r") 
        all_lines = fp_file.readlines()
        fp_file.close()
        if len(all_lines) <= 2:
            continue
        prefill_cost = float(all_lines[0].split(":")[1].strip())
        firststep_cost = float(all_lines[1].split(":")[1].strip())
        laststep_cost = float(all_lines[-2].split(":")[1].strip())
        all_step_cost = float(all_lines[-1].split(":")[1].strip())
        mean_step_cost = (all_step_cost - prefill_cost) / float(output_len)
        card_num_per_qps =  float(world_size) / (float(batch_size) / (all_step_cost / 1000))
        prefill_throughput = float(batch_size) * float(input_len) / (prefill_cost / 1000)
        decode_throughput = float(batch_size) * float(output_len) / ((all_step_cost - prefill_cost) / 1000)
        total_throughput = float(batch_size) * (float(input_len) + float(output_len)) / (all_step_cost / 1000)
        md_file.write('|')
        infos = [mode, world_size, batch_size, input_len, output_len, prefill_cost, firststep_cost, laststep_cost, mean_step_cost,
                 prefill_throughput, decode_throughput, total_throughput,
                  card_num_per_qps]
        for info in infos:
            md_file.write(str(format(info, ".4f")) if isinstance(info, float) else str(info))
            md_file.write("|")
        md_file.write('\r\n')
    md_file.close()

if __name__ == '__main__':

    import torch
    torch.multiprocessing.set_start_method("spawn")

    for model_name, setting in model_to_class_and_path.items():
        print(f"test {model_name}\n{setting}")
        test_all_setting(
                 model_name=model_name,
                 modes=setting['modes'],
                 log_dir="/nvme/ci_performance/log_dir/lightllm/static_speed/", 
                 world_sizes=setting["world_sizes"],
                 in_out_lens=setting["in_out_lens"], 
                 batch_sizes=setting["batch_sizes"],
                 model_class=setting["model_type"],
                 model_path=setting["model_path"])
