#!/bin/bash
model_type=llama3-8b
logdir="/nvme/ci_performance/log_dir/sglang/service/${model_type}"  # 请替换为实际的日志目录
# 检查目录是否成功创建  
if [ -d "$logdir" ]; then  
    echo "目录 $logdir 正常"  
else 	
    echo "创建目录 $logdir" 
    mkdir -p "$logdir"   
fi
port=23334
request_num=1000
model_dir=/nvme/ci_performance/models/Meta-Llama-3.1-8B-Instruct/
COMMAND="python3 -m sglang.launch_server \
    --host 0.0.0.0                 \
    --port ${port} \
    --model-path ${model_dir} \
    --tokenizer-path ${model_dir} \
    --tokenizer-mode auto \
    --mem-fraction-static 0.9 \
    --trust-remote-code \
    --dtype bfloat16 \
    --max-prefill-tokens 8192 \
    --context-length 8192 \
    --tensor-parallel-size 1"

echo "$COMMAND"
eval "$COMMAND" > server.log 2>&1 &
timeout 600 bash -c "until curl http://0.0.0.0:${port}/health; do sleep 10; done" || { echo "Server failed to start"; pkill python; exit 1; } 

declare -a num_clients=(5 10 15 20)
declare -a input_len=(256 512 1024 2048)  
declare -a output_len=(128 256 512) 

for input in "${input_len[@]}"; do
    for output in "${output_len[@]}"; do
        for clients in "${num_clients[@]}"; do
            outfile="${logdir}/sglang##${model_type}##tp_1##inputlen_${input}##outputlen_${output}##clients_${clients}.json"
            if [[ -f "$outfile" ]]; then
		echo "$outfile exists:"
                cat "$outfile"
                continue
            fi
            # warmup with 40 requests
            echo "Begin Warmup!"
            llm_profiler --config configs/config_pileval_stream.yml \
                --url 0.0.0.0:"$port"/v1/completions \
                --num_clients "$clients" \
                --post_mode stream \
                --data_source pileval \
                --server_api openai \
                --data_path /nvme/ci_performance/dataset/pileval/ \
                --tokenizer_path "$model_dir" \
                --input_num 40 \
                --input_len "$input" \
                --output_len "$output" > warmup.log
            echo "Begin testing, results saved in $outfile"
            llm_profiler --config configs/config_pileval_stream.yml \
                --url 0.0.0.0:"$port"/v1/completions \
                --num_clients "$clients" \
                --post_mode stream \
                --data_source pileval \
                --server_api openai \
                --data_path /nvme/ci_performance/dataset/pileval/ \
		--tokenizer_path "$model_dir" \
                --input_num "$request_num" \
		--input_len "$input" \
                --output_len "$output" \
                --dump_file "$outfile"
        done
    done
done

# pkill -f python
