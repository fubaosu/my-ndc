#!/bin/bash

# 定义模型数组和路径数组
models=("sensechat-100b" "deepseek-v2-lite" "qwen2-57b" "mixtral-8x7b" "mixtral-8x22b"  "llama3-8b" "llama3-70b")
paths=("sensechat5_102b_128k_5150" "DeepSeek-V2-Chat-Lite" "Qwen2-57B-A14B-Instruct" "Mixtral-8x7B-Instruct-v0.1" "Mixtral-8x22B-Instruct-v0.1"  "Meta-Llama-3-8B-Instruct-hf" "Meta-Llama-3-70B-Instruct-hf")
tps=(4 1 4 4 8 1 4)
# 获取数组的长度
length=${#models[@]}

# 循环遍历数组
for (( i=0; i<$length; i++ ))
do
    # echo "Processing ${models[$i]} at ${paths[$i]} with tp ${tps[$i]}"
    # 这里可以加入对每个模型和路径的处理逻辑
    echo ./benchmark/vllm/general+h100-80g_launcher.sh ${models[$i]} "/data/models/${paths[$i]}" ${tps[$i]}
    bash ./benchmark/vllm/general+h100-80g_launcher.sh ${models[$i]} "/data/models/${paths[$i]}" ${tps[$i]}
done