#!/bin/bash

batch_sizes="1,2,4,8,12,16,32,64"
input_lens=(1024 2048 4096 8192 16384 32768 131072)

models=("sensechat-100b" "deepseek-v2-lite" "qwen2-57b" "mixtral-8x7b" "mixtral-8x22b"  "llama3-8b" "llama3-70b" "deepseek-v2")
paths=("sensechat5_102b_128k_5150" "DeepSeek-V2-Chat-Lite" "Qwen2-57B-A14B-Instruct" "Mixtral-8x7B-Instruct-v0.1" "Mixtral-8x22B-Instruct-v0.1"  "Meta-Llama-3-8B-Instruct-hf" "Meta-Llama-3-70B-Instruct-hf" "DeepSeek-V2-Chat")
tps=(4 1 4 4 8 1 4 8)

length=${#models[@]}
for (( i=0; i<$length; i++ ))
do
    for input_len in "${input_lens[@]}"
    do
        echo python3 benchmark_latency.py --model "/data/models/${paths[$i]}" --output-len 30 --batch-sizes $batch_sizes --input-len $input_len --tensor-parallel-size ${tps[$i]} --trust-remote-code --num-iters-warmup 5 --num-iters 5 --result-dir /data/log_dir/vllm-static/${models[$i]}
        python3 benchmark_latency.py --model "/data/models/${paths[$i]}" --output-len 30 --batch-sizes $batch_sizes --input-len $input_len --tensor-parallel-size ${tps[$i]} --trust-remote-code --num-iters-warmup 5 --num-iters 5 --result-dir /data/log_dir/vllm-static/${models[$i]}
    done
done
