import argparse
import yaml
import requests
import json
import time
import random
import numpy as np
from tqdm import tqdm
from easydict import EasyDict
from concurrent.futures import ThreadPoolExecutor
from llm_profiler.data import *
from llm_profiler.utils import seed_all, update_config_from_args
model_name = []
def post_nostream_lightllm(url, text_input, max_new_tokens):
    data = {
        "inputs": text_input,
        "parameters": {
            'do_sample': False,
            'ignore_eos': False,
            'max_new_tokens': max_new_tokens,
        }
    }
    headers = {'Content-Type': 'application/json'}
    start_time = time.time()
    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    end_time = time.time()
    return (response.json(), end_time - start_time)

def post_nostream_vllm(url, text_input, max_new_tokens):
    data = {
        "prompt": text_input,
        "n": 1,
        'ignore_eos': False,
        'max_tokens': max_new_tokens,
        "stream": False,
    }
    headers = {'Content-Type': 'application/json'}
    start_time = time.time()
    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    end_time = time.time()
    return (response.json(), end_time - start_time)

def post_nostream_triton(url, text_input, max_new_tokens):
    data = {
        'text_input': text_input,
        "max_tokens": max_new_tokens
    }
    headers = {'Content-Type': 'application/json'}
    start_time = time.time()
    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    end_time = time.time()
    return (response.json(), end_time - start_time)

def post_stream_lightllm(url, text_input, max_new_tokens):
    data = {
        "inputs": text_input,
        "parameters": {
            'do_sample': False,
            'ignore_eos': False,
            'max_new_tokens': max_new_tokens,
        }
    }
    headers = {'Content-Type': 'application/json'}
    used_time = []
    start_time = time.time()
    last_time = start_time
    response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
    if response.status_code != 200:
        print(response.json())
    assert response.status_code == 200
    for line in response.iter_lines():
        if line:
            current_time = time.time()
            elapsed_time = current_time - last_time
            used_time.append(elapsed_time)
            # print(line.decode("utf-8"))
            last_time = current_time
    return used_time

def post_stream_vllm(url, text_input, max_new_tokens):
    data = {
        "prompt": text_input,
        "n": 1,
        'ignore_eos': False,
        'max_tokens': max_new_tokens,
        "stream": True,
    }
    headers = {'Content-Type': 'application/json'}
    used_time = []
    start_time = time.time()
    last_time = start_time
    response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
    assert response.status_code == 200
    for line in response.iter_lines(chunk_size=8192,
                                     decode_unicode=False,
                                     delimiter=b"\0"):
        if line:
            current_time = time.time()
            elapsed_time = current_time - last_time
            used_time.append(elapsed_time)
            # print(line.decode("utf-8"))
            last_time = current_time
    return used_time

def post_stream_lmdeploy(url, text_input, max_new_tokens):
    data = {
        "model": model_name[0], 
        "prompt": text_input,
        "n": 1,
        'ignore_eos': False,
        'max_tokens': max_new_tokens - 1, # lmdeploy的输出长度是max_tokens -1 ,所以这里手动-1
        "stream": True,
    }
    headers = {'Content-Type': 'application/json'}
    used_time = []
    start_time = time.time()
    last_time = start_time
    response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
    assert response.status_code == 200
    for line in response.iter_content(chunk_size=8192):
        line = line.strip()
        if line:
            line = line.decode("utf-8")[6:]    # remove "data: "
            if line == "[DONE]":
                continue
            data = json.loads(line) 
            if not data["choices"][0]["text"]:
                continue
            current_time = time.time()
            elapsed_time = current_time - last_time
            used_time.append(elapsed_time)
            last_time = current_time
    return used_time

def post_stream_openai(url, text_input, max_new_tokens):
    data = {
        "model": model_name[0],
        "prompt": text_input,
        "n": 1,
        'ignore_eos': False,
        'max_tokens': max_new_tokens, 
        "stream": True,
    }
    headers = {'Content-Type': 'application/json'}
    used_time = []
    start_time = time.time()
    last_time = start_time
    response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
    assert response.status_code == 200
    for line in response.iter_content(chunk_size=8192):
        line = line.strip()
        if line:
            line = line.decode("utf-8")[6:]    # remove "data: "
            if line == "[DONE]":
                continue
            data = json.loads(line)
            if not data["choices"][0]["text"]:
                continue
            current_time = time.time()
            elapsed_time = current_time - last_time
            used_time.append(elapsed_time)
            last_time = current_time
    return used_time

def post_stream_triton(url, text_input, max_new_tokens):
    data = {
        'text_input': text_input,
        "max_tokens": max_new_tokens, "stream": True
    }
    headers = {'Content-Type': 'application/json'}
    used_time = []
    start_time = time.time()
    last_time = start_time
    response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
    assert response.status_code == 200
    for line in response.iter_lines():
        if line:
            current_time = time.time()
            elapsed_time = current_time - last_time
            used_time.append(elapsed_time)
            # print(line.decode("utf-8"))
            last_time = current_time
    return used_time

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    parser.add_argument('--url', type=str, default="")
    parser.add_argument('--num_clients', type=int, default=0)
    parser.add_argument('--post_mode', type=str, choices=["", "stream", "nostream"], default="")
    parser.add_argument('--data_source', type=str, choices=["", "custom", "pileval"], default="")
    parser.add_argument('--data_path', type=str, default="")
    parser.add_argument('--tokenizer_path', type=str, default="")
    parser.add_argument('--data_mode', type=str, default="")
    parser.add_argument('--input_len', type=int, default=0)
    parser.add_argument('--input_num', type=int, default=0)
    parser.add_argument('--output_len', type=int, default=0)
    parser.add_argument('--server_api', type=str, default="")
    parser.add_argument('--dump_file', type=str, default="")
    parser.add_argument('--trust_remote_code', action='store_true', default=False)

    args = parser.parse_args()
    if args.dump_file and os.path.exists(args.dump_file):
        # 读取并输出 JSON 内容
        with open(args.dump_file, 'r') as json_file:
            content = json.load(json_file)
            print(json.dumps(content, indent=4))
        return 

    with open(args.config, 'r') as file:
        config = yaml.safe_load(file)
    config = EasyDict(config)
    config = update_config_from_args(config, args)
    print(f'config:\n{json.dumps(config, ensure_ascii=False, indent=4)}')
    model_name.append(args.tokenizer_path)
    seed_all(config.seed)
    url = config.url
    if config.data_source == "pileval":
        prompts, input_lens = get_pileval_input_data(config.data_path, config.tokenizer_path, config.input_len, config.input_num, config.data_mode, config.show_seqlen)
        max_new_tokens = get_output_length(len(prompts), config.output_len)

    elif config.data_source == "custom":
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(args.tokenizer_path, trust_remote_code=args.trust_remote_code)
        prompts, input_lens = get_custom_input_data(config.data_path, tokenizer)
        max_new_tokens = [config.output_len] * len(prompts)

    percentiles = config.percentiles
    if config.server_api == "lightllm":
        post_stream = post_stream_lightllm
        post_nostream = post_nostream_lightllm
    elif config.server_api == "vllm":
        post_stream = post_stream_vllm
        post_nostream = post_nostream_vllm
    elif config.server_api == "lmdeploy":
        post_stream = post_stream_lmdeploy
    elif config.server_api == "openai":
        post_stream = post_stream_openai
    elif config.server_api == "triton":
        post_stream = post_stream_triton
        post_nostream = post_nostream_triton
    else:
        raise Exception(f'Not support {config.server_api} server_api.')
    dump_dict = {}
    dump_dict["backend"] = config.server_api
    dump_dict["clients"] = config.num_clients
    start_time = time.time()
    if config.post_mode == "stream":
        with ThreadPoolExecutor(max_workers=config.num_clients) as executor:
            results = list(tqdm(executor.map(lambda p: post_stream(url, p[0], p[1]), zip(prompts, max_new_tokens)), total=len(prompts), desc="Running tests"))
        end_time = time.time()
        first_token_time = []
        decode_token_time = []
        request_time = []
        final_output_lens = []
        valid_num = 0
        for result in results:
            if len(result) > 1: # 统计至少decode出两个token的数据
                first_token_time.append(result[0])
                decode_token_time.append(sum(result[1:]) / len(result[1:]))
                request_time.append(sum(result))
                final_output_lens.append(len(result))
                valid_num += 1
        print(f"\n\nvalid num = {valid_num}; all data num = {len(results)}; valid ratio = {valid_num * 1.0 / len(results)}\n")
        print(f"Total QPS: {valid_num / (end_time - start_time)}")
        print(f"Avg Input Length: {sum(input_lens) / len(input_lens)}")
        print(f"Avg Output Length: {sum(final_output_lens) / len(final_output_lens)}")
        print(f"Total Throughput: {(sum(input_lens) + sum(max_new_tokens)) / (end_time - start_time)} token/s")
        print(f"Input Throughput: {sum(input_lens) / (end_time - start_time)} token/s")
        print(f"Output Throughput: {sum(max_new_tokens) / (end_time - start_time)} token/s")
        print("-" * 10)
        dump_dict["request_num"] = valid_num
        dump_dict["Total QPS"] = valid_num / (end_time - start_time)
        dump_dict["Avg Input Length"] = sum(input_lens) / len(input_lens)
        dump_dict["Avg Output Length"] = sum(final_output_lens) / len(final_output_lens)
        dump_dict["Total Throughput"] = (sum(input_lens) + sum(max_new_tokens)) / (end_time - start_time)
        dump_dict["Input Throughput"] = sum(input_lens) / (end_time - start_time)
        dump_dict["Output Throughput"] = sum(input_lens) / (end_time - start_time)

        values = np.percentile(request_time, percentiles, method="lower")
        request_time_dict = {}
        for percentile, value in zip(percentiles, values):
            print(f"request_time P{percentile}: {value:.6f}s")
            request_time_dict[f"P{percentile}"] = value
        dump_dict["request_time"] = request_time_dict 
        print("-" * 10)
        
        first_token_time_dict = {}
        values = np.percentile(first_token_time, percentiles, method="lower")
        for percentile, value in zip(percentiles, values):
            print(f"first_token_time  P{percentile}: {value:.6f}s")
            first_token_time_dict[f"P{percentile}"] = value
        dump_dict["first_token_time_dict"] = first_token_time_dict
        print("-" * 10)

        decode_token_time_dict = {}
        values = np.percentile(decode_token_time, percentiles, method="lower")
        for percentile, value in zip(percentiles, values):
            print(f"decode_token_time  P{percentile}: {value * 1000:.6f}ms")
            decode_token_time_dict[f"P{percentile}"] = value * 1000
        dump_dict["decode_token_time_dict"] = decode_token_time_dict
        print(dump_dict)
    elif config.post_mode == "nostream":
        with ThreadPoolExecutor(max_workers=config.num_clients) as executor:
            results = list(tqdm(executor.map(lambda p: post_nostream(url, p[0], p[1]), zip(prompts, max_new_tokens)), total=len(prompts), desc="Running tests"))
        end_time = time.time()
        used_times = []
        for result in results:
            used_times.append(result[1])

        print(f"Total QPS: {len(results) / (end_time - start_time)}")
        print(f"Total Throughput: {(sum(input_lens) + sum(max_new_tokens)) / (end_time - start_time)} token/s")
        print(f"Input Throughput: {sum(input_lens) / (end_time - start_time)} token/s")
        print(f"Output Throughput: {sum(max_new_tokens) / (end_time - start_time)} token/s")
        values = np.percentile(used_times, percentiles, method="lower")
        request_time_dict = {}
        for percentile, value in zip(percentiles, values):
            print(f"request_time P{percentile}: {value:.6f}s")
            request_time_dict[f"P{percentile}"] = value
        dump_dict["request_time"] = request_time_dict
        print("-" * 10)
    else:
        raise Exception(f'Not support {config.post_mode} post_mode.')
    if args.dump_file:
        with open(args.dump_file, 'w') as json_file:
            json.dump(dump_dict, json_file, indent=4)
        print(f"Results have been written to {args.dump_file}")
if __name__ == "__main__":
    main()
