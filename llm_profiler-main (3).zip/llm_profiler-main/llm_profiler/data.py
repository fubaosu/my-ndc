from datasets import load_from_disk
from transformers import AutoTokenizer
import json
from llm_profiler.utils import *

def get_pileval_input_data(data_path, tokenizer_path, input_len, input_num, mode="uniform", show_seqlen=False):
    print("Loading pileval data...")
    data = load_from_disk(data_path)
    data = '\n'.join(data['text'][:3000])
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, trust_remote_code=True)
    input_ids = tokenizer.encode(data)
    if mode == "uniform":
        prompts_ids = uniform_distribution(input_ids, input_num, input_len)
    elif mode == "random":
        prompts_ids = random_distribution(input_ids, input_num, input_len)
    elif mode == "gaussian":
        prompts_ids = gaussian_distribution(input_ids, input_num, input_len)
    elif mode == "increasing":
        prompts_ids = increasing_distribution(input_ids, input_num, input_len)
    elif mode == "decreasing":
        prompts_ids = decreasing_distribution(input_ids, input_num, input_len)
    else:
        raise Exception(f'Not support {mode} mode.')

    if show_seqlen:
        show_seqlen_distribution(prompts_ids)

    prompts = []
    input_lens = []
    for prompts_id in prompts_ids:
        text = tokenizer.decode(prompts_id)
        prompts.append(text)
        input_lens.append(len(prompts_id))
    print("Finish loading.")
    return prompts, input_lens

def chat_format(query):
    template = "<|im_start|>system\n你是一个乐于助人的人工智能助手。<|im_end|>\n<|im_start|>user\n<to_be_replaced><|im_end|>\n<|im_start|>assistant\n"
    input_text = template.replace("<to_be_replaced>", query)
    return input_text

def get_custom_input_data(data_path, tokenizer):
    prompts = []
    input_lens = []
    with open(data_path, "r") as f:
        for l in f.readlines():
            data_line = json.loads(l)
            input_data = tokenizer.apply_chat_template(data_line["messages"], add_generation_prompt=True)
            input_lens.append(len(input_data))
            prompts.append(tokenizer.decode(input_data))
    return prompts, input_lens

def get_output_length(input_num, output_len):
    min_len, max_len = 2, output_len * 2
    mean = (min_len + max_len) * 0.5
    std = (max_len - mean) / 3.0 # 3std准则
    output_lens = []
    for _ in range(input_num):
        cur_len = random.gauss(mean, std)
        cur_len = round(cur_len)
        if cur_len < min_len:
            cur_len = min_len
        elif cur_len > max_len:
            cur_len = max_len
        output_lens.append(cur_len)
    return output_lens 

