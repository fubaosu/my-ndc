import argparse
from datasets import load_dataset

parser = argparse.ArgumentParser()
parser.add_argument("--save_path", type=str, required=True)
args = parser.parse_args()

calib_dataset = load_dataset("mit-han-lab/pile-val-backup", split="validation")

calib_dataset.save_to_disk(args.save_path)
print("download pileval for calib finished.")
